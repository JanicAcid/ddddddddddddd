<?php
/**
 * kassa-cto.ru API Router — PHP proxy for Telegram
 * Handles: send-order, captcha, chat/send, chat/poll
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Cache-Control: no-store, no-cache, must-revalidate');

// CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Load config
$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    jsonResponse(['error' => 'API not configured'], 500);
    exit;
}

$config = require $configPath;
$botToken = $config['TELEGRAM_BOT_TOKEN'] ?? '';
$chatId = $config['OPERATOR_CHAT_ID'] ?? '';

if (empty($botToken) || empty($chatId)) {
    jsonResponse(['error' => 'API not configured: missing TELEGRAM_BOT_TOKEN or OPERATOR_CHAT_ID'], 500);
    exit;
}

// Parse request path
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($requestUri, PHP_URL_PATH);

// Normalize: remove /api/ prefix
$path = preg_replace('#^/api/#', '', $path);
$path = rtrim($path, '/');
$method = $_SERVER['REQUEST_METHOD'];

// Route
try {
    switch ("$method $path") {
        case 'GET captcha':
            handleCaptcha();
            break;

        case 'POST send-order':
            handleSendOrder($botToken, $chatId);
            break;

        case 'POST log-order':
            handleLogOrder();
            break;

        case 'POST chat/send':
            handleChatSend($botToken, $chatId);
            break;

        case 'GET chat/poll':
            handleChatPoll();
            break;

        default:
            jsonResponse(['error' => 'Not Found'], 404);
    }
} catch (Throwable $e) {
    jsonResponse(['error' => 'Internal Server Error: ' . $e->getMessage()], 500);
}

// ========== HANDLERS ==========

function handleCaptcha(): void
{
    $a = rand(1, 20);
    $b = rand(1, 20);
    $ops = ['+', '-', '*'];
    $op = $ops[array_rand($ops)];

    switch ($op) {
        case '+':
            $answer = $a + $b;
            $question = "$a + $b = ?";
            break;
        case '-':
            $answer = $a - $b;
            $question = "$a - $b = ?";
            break;
        case '*':
            $answer = $a * $b;
            $question = "$a \u{00d7} $b = ?";
            break;
    }

    $captchaId = bin2hex(random_bytes(4));
    $token = base64_encode(json_encode(['answer' => $answer, 'ts' => time()]));

    jsonResponse([
        'id' => $captchaId,
        'question' => $question,
        'token' => $token,
    ]);
}

function handleSendOrder(string $botToken, string $chatId): void
{
    $input = getJsonInput();
    $subject = $input['subject'] ?? '';
    $html = $input['html'] ?? '';

    if (empty($subject) || empty($html)) {
        jsonResponse(['error' => 'Missing fields'], 400);
        return;
    }

    sendTelegramDocument($botToken, $chatId, $html, $subject);
    jsonResponse(['success' => true, 'sentTo' => 'telegram']);
}

function handleLogOrder(): void
{
    // Google Sheets logging is not available on Beget shared hosting
    // Stub: accept the request but skip logging
    $input = getJsonInput();
    jsonResponse(['success' => true, 'logged' => false, 'note' => 'Google Sheets logging not available on static hosting']);
}

function handleChatSend(string $botToken, string $chatId): void
{
    $input = getJsonInput();
    $message = $input['message'] ?? $input['text'] ?? '';
    $name = $input['name'] ?? $input['senderName'] ?? 'Клиент';

    if (empty($message)) {
        jsonResponse(['error' => 'Empty message'], 400);
        return;
    }

    // Send to Telegram
    $text = "<b>💬 Сообщение с сайта</b>\n";
    $text .= "<b>Имя:</b> " . htmlspecialchars($name) . "\n";
    $text .= "<b>Время:</b> " . date('d.m.Y H:i:s') . "\n\n";
    $text .= htmlspecialchars($message);

    sendTelegramMessage($botToken, $chatId, $text);

    jsonResponse(['success' => true, 'id' => time()]);
}

function handleChatPoll(): void
{
    // Chat history is not persisted on static hosting
    jsonResponse(['messages' => [], 'hasMore' => false]);
}

// ========== TELEGRAM FUNCTIONS ==========

function sendTelegramMessage(string $botToken, string $chatId, string $text): void
{
    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";

    $payload = [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ];

    $response = httpRequest($url, $payload);

    if (!$response['ok']) {
        error_log("Telegram sendMessage error: " . json_encode($response));
    }
}

function sendTelegramDocument(string $botToken, string $chatId, string $html, string $subject): void
{
    $url = "https://api.telegram.org/bot{$botToken}/sendDocument";

    $boundary = '----FormBoundary' . bin2hex(random_bytes(8));

    $filename = preg_replace('/[^a-zA-Zа-яА-Я0-9_\-\s]/u', '', $subject);
    $filename = trim($filename) ?: 'order';
    $filename .= '.html';

    $body = "--{$boundary}\r\n";
    $body .= "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n";
    $body .= "{$chatId}\r\n";
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Disposition: form-data; name=\"document\"; filename=\"{$filename}\"\r\n";
    $body .= "Content-Type: text/html; charset=utf-8\r\n\r\n";
    $body .= $html . "\r\n";
    $body .= "--{$boundary}--\r\n";

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => [
            "Content-Type: multipart/form-data; boundary={$boundary}",
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        error_log("Telegram sendDocument curl error: " . curl_error($ch));
    } elseif ($httpCode !== 200) {
        error_log("Telegram sendDocument error ({$httpCode}): {$response}");
    }

    curl_close($ch);
}

// ========== HELPERS ==========

function jsonResponse(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function getJsonInput(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function httpRequest(string $url, array $payload): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        return json_decode($response, true) ?: ['ok' => false, 'description' => 'Empty response'];
    }

    return ['ok' => false, 'description' => "HTTP {$httpCode}", 'code' => $httpCode];
}
