<?php
/**
 * kassa-cto.ru API Configuration
 * Telegram bot token and chat ID
 */

return [
    // Telegram bot token (get from @BotFather)
    'TELEGRAM_BOT_TOKEN' => '8608302760:AAFuM_LPaFqfIgM_QVse4gukmf_k5lCNehg',

    // Chat ID where orders/messages are sent (get from @userinfobot)
    'OPERATOR_CHAT_ID' => '391081654',
];
